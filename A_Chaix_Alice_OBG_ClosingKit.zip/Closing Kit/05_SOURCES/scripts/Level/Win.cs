using Godot;
using System;

namespace Com.IsartDigital.OneButtonGame.Level {
	
    public class Win : Area2D
    {
        public static Win Instance { get; private set; }

        private Win ():base() {}

        [Export] PackedScene winScreen;

        public override void _Ready()
        {
            if (Instance != null){  
                Free();
                GD.Print($"{nameof(Win)} Instance already exist, destroying the last added.");
                return;
            }
            
            Instance = this;

            Connect("area_entered", this, nameof(OnCollision));
        }

        protected void OnCollision(Area2D pArea)
        {
            if (pArea == Player.Instance.area)
            {
                GetTree().Paused = true;
                GetParent().AddChild(winScreen.Instance());
            }
        }

        protected override void Dispose(bool pDisposing)
        {
            if (pDisposing && Instance == this) 
                Instance = null;

            base.Dispose(pDisposing);
        }
    }
}